package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.repository.DemoAuthRepository
import com.example.data.repository.DemoRewardRepository
import com.example.ui.screens.TechRewardApp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        // Inject repositories
        val authRepo = DemoAuthRepository()
        val rewardRepo = DemoRewardRepository(authRepo)

        setContent {
            MyApplicationTheme {
                TechRewardApp(authRepo, rewardRepo)
            }
        }
    }
}
