package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import java.util.concurrent.TimeUnit

class DemoAuthRepository : AuthRepository {
    private val _currentUser = MutableStateFlow<User?>(null)
    override val currentUser: Flow<User?> = _currentUser.asStateFlow()
    override val isDemoMode: Boolean = true

    override suspend fun login(email: String, pass: String): Result<Unit> {
        delay(1000)
        if (email == "admin@test.com") {
            _currentUser.value = User(id = "admin123", name = "Admin", email = email, isAdmin = true)
        } else {
            _currentUser.value = User(id = "demo123", name = "Demo User", email = email, coinBalance = 1500)
        }
        return Result.success(Unit)
    }

    override suspend fun register(name: String, email: String, pass: String): Result<Unit> {
        delay(1000)
        _currentUser.value = User(id = UUID.randomUUID().toString(), name = name, email = email, coinBalance = 0)
        return Result.success(Unit)
    }

    override suspend fun logout() {
        _currentUser.value = null
    }
    
    fun updateCurrentUser(user: User) {
        _currentUser.value = user
    }
    
    fun getCurrentUserSync() = _currentUser.value
}

class DemoRewardRepository(private val auth: DemoAuthRepository) : RewardRepository {
    
    private val transactions = mutableListOf<Transaction>()
    private val withdrawals = mutableListOf<Withdrawal>()
    
    private val demoTasks = mutableListOf(
        Task("t1", "📺 Rewarded Ad", "একটি সম্পূর্ণ Rewarded Ad দেখুন", 10, TaskType.REWARDED_AD),
        Task("t2", "🌐 Website Visit", "আমাদের ওয়েবসাইট ভিজিট করুন", 20, TaskType.WEBSITE_VISIT),
        Task("t3", "📤 Share App", "বন্ধুদের সাথে শেয়ার করুন", 30, TaskType.SHARE_APP)
    )

    override suspend fun getTasks(): List<Task> {
        delay(500)
        return demoTasks
    }

    override suspend fun completeTask(taskId: String): Result<Int> {
        delay(800)
        val user = auth.getCurrentUserSync() ?: return Result.failure(Exception("Not logged in"))
        val task = demoTasks.find { it.id == taskId } ?: return Result.failure(Exception("Task not found"))
        
        val newBalance = user.coinBalance + task.rewardCoins
        val newEarned = user.totalEarned + task.rewardCoins
        
        auth.updateCurrentUser(user.copy(coinBalance = newBalance, totalEarned = newEarned))
        transactions.add(Transaction(UUID.randomUUID().toString(), user.id, task.title, task.rewardCoins))
        return Result.success(task.rewardCoins)
    }

    override suspend fun claimDailyBonus(): Result<Int> {
        delay(800)
        val user = auth.getCurrentUserSync() ?: return Result.failure(Exception("Not logged in"))
        val now = System.currentTimeMillis()
        val oneDayMs = TimeUnit.DAYS.toMillis(1)
        
        if (now - user.lastDailyBonusAt < oneDayMs) {
            return Result.failure(Exception("আজকের Bonus নেওয়া হয়েছে। আগামীকাল আবার আসুন।"))
        }
        
        val bonus = 50
        auth.updateCurrentUser(user.copy(
            coinBalance = user.coinBalance + bonus,
            totalEarned = user.totalEarned + bonus,
            lastDailyBonusAt = now
        ))
        transactions.add(Transaction(UUID.randomUUID().toString(), user.id, "Daily Bonus", bonus))
        return Result.success(bonus)
    }

    override suspend fun spinWheel(): Result<Int> {
        delay(800)
        val user = auth.getCurrentUserSync() ?: return Result.failure(Exception("Not logged in"))
        val now = System.currentTimeMillis()
        val oneDayMs = TimeUnit.DAYS.toMillis(1)
        
        if (now - user.lastSpinAt < oneDayMs) {
            return Result.failure(Exception("আজকের Spin করা হয়েছে। আগামীকাল আবার চেষ্টা করুন।"))
        }
        
        val rewards = listOf(10, 20, 30, 50, 100)
        val won = rewards.random()
        
        auth.updateCurrentUser(user.copy(
            coinBalance = user.coinBalance + won,
            totalEarned = user.totalEarned + won,
            lastSpinAt = now
        ))
        transactions.add(Transaction(UUID.randomUUID().toString(), user.id, "Spin & Win", won))
        return Result.success(won)
    }

    override suspend fun requestWithdrawal(method: String, mobileNumber: String, amount: Int): Result<Unit> {
        delay(1000)
        val user = auth.getCurrentUserSync() ?: return Result.failure(Exception("Not logged in"))
        if (user.coinBalance < amount) {
            return Result.failure(Exception("পর্যাপ্ত ব্যালেন্স নেই।"))
        }
        if (amount < 5000) {
            return Result.failure(Exception("Minimum withdrawal: 5,000 Coin"))
        }
        
        auth.updateCurrentUser(user.copy(coinBalance = user.coinBalance - amount))
        withdrawals.add(0, Withdrawal(UUID.randomUUID().toString(), user.id, method, mobileNumber, amount))
        transactions.add(0, Transaction(UUID.randomUUID().toString(), user.id, "Withdrawal", -amount))
        return Result.success(Unit)
    }

    override suspend fun getWithdrawalHistory(): List<Withdrawal> {
        delay(500)
        val user = auth.getCurrentUserSync() ?: return emptyList()
        return withdrawals.filter { it.userId == user.id }.sortedByDescending { it.createdAt }
    }

    override suspend fun getTransactionHistory(): List<Transaction> {
        delay(500)
        val user = auth.getCurrentUserSync() ?: return emptyList()
        return transactions.filter { it.userId == user.id }.sortedByDescending { it.createdAt }
    }

    override suspend fun getAllUsers(): List<User> {
        delay(500)
        val user = auth.getCurrentUserSync() ?: return emptyList()
        return listOf(user)
    }

    override suspend fun getPendingWithdrawals(): List<Withdrawal> {
        delay(500)
        return withdrawals.filter { it.status == "Pending" }
    }

    override suspend fun approveWithdrawal(id: String): Result<Unit> {
        delay(500)
        val index = withdrawals.indexOfFirst { it.id == id }
        if (index != -1) {
            withdrawals[index] = withdrawals[index].copy(status = "Approved")
            return Result.success(Unit)
        }
        return Result.failure(Exception("Not found"))
    }
}
