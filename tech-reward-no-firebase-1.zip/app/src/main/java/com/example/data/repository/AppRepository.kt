package com.example.data.repository

import com.example.data.model.Task
import com.example.data.model.Transaction
import com.example.data.model.User
import com.example.data.model.Withdrawal
import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    val currentUser: Flow<User?>
    suspend fun login(email: String, pass: String): Result<Unit>
    suspend fun register(name: String, email: String, pass: String): Result<Unit>
    suspend fun logout()
    val isDemoMode: Boolean
}

interface RewardRepository {
    suspend fun getTasks(): List<Task>
    suspend fun completeTask(taskId: String): Result<Int> // returns coins added
    
    suspend fun claimDailyBonus(): Result<Int>
    suspend fun spinWheel(): Result<Int>
    
    suspend fun requestWithdrawal(method: String, mobileNumber: String, amount: Int): Result<Unit>
    
    suspend fun getWithdrawalHistory(): List<Withdrawal>
    suspend fun getTransactionHistory(): List<Transaction>
    
    // Admin ops
    suspend fun getAllUsers(): List<User>
    suspend fun getPendingWithdrawals(): List<Withdrawal>
    suspend fun approveWithdrawal(id: String): Result<Unit>
}
