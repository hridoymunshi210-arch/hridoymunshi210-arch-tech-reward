package com.example.data.model

data class User(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val coinBalance: Int = 0,
    val totalEarned: Int = 0,
    val totalWithdrawn: Int = 0,
    val lastDailyBonusAt: Long = 0L,
    val lastSpinAt: Long = 0L,
    val isAdmin: Boolean = false
)

enum class TaskType {
    REWARDED_AD, WEBSITE_VISIT, SHARE_APP
}

data class Task(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val rewardCoins: Int = 0,
    val type: TaskType = TaskType.REWARDED_AD,
    val enabled: Boolean = true
)

data class Transaction(
    val id: String = "",
    val userId: String = "",
    val type: String = "",
    val amount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

data class Withdrawal(
    val id: String = "",
    val userId: String = "",
    val method: String = "", 
    val mobileNumber: String = "",
    val coinAmount: Int = 0,
    val status: String = "Pending", 
    val createdAt: Long = System.currentTimeMillis()
)
