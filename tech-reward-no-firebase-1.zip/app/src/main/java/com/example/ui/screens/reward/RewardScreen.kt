package com.example.ui.screens.reward

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.repository.AuthRepository
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.launch

@Composable
fun RewardScreen(authRepo: AuthRepository, rewardRepo: RewardRepository) {
    val currentUser by authRepo.currentUser.collectAsState(initial = null)
    var mobileNumber by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("bKash") }
    var isSubmitting by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Reward",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "আপনার Coin")
                Text(
                    text = "${currentUser?.coinBalance ?: 0} Coin",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Minimum withdrawal: 5,000 Coin", style = MaterialTheme.typography.bodySmall)
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Method selection
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            FilterChip(
                selected = method == "bKash",
                onClick = { method = "bKash" },
                label = { Text("bKash") }
            )
            FilterChip(
                selected = method == "Nagad",
                onClick = { method = "Nagad" },
                label = { Text("Nagad") }
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = mobileNumber,
            onValueChange = { mobileNumber = it },
            label = { Text("Mobile Number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = amountText,
            onValueChange = { amountText = it },
            label = { Text("Coin Amount") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        message?.let {
            Text(text = it, color = if (it.contains("গ্রহণ")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.height(8.dp))
        }

        Button(
            onClick = {
                val amount = amountText.toIntOrNull()
                if (amount == null || mobileNumber.isBlank()) {
                    message = "সঠিক নাম্বার এবং এমাউন্ট দিন।"
                    return@Button
                }
                
                isSubmitting = true
                message = null
                scope.launch {
                    val res = rewardRepo.requestWithdrawal(method, mobileNumber, amount)
                    if (res.isSuccess) {
                        message = "আপনার withdrawal request গ্রহণ করা হয়েছে। বর্তমানে Status: Pending"
                        mobileNumber = ""
                        amountText = ""
                    } else {
                        message = res.exceptionOrNull()?.message ?: "দুঃখিত, Request পাঠানো যায়নি।"
                    }
                    isSubmitting = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isSubmitting
        ) {
            if (isSubmitting) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text("Withdraw Request পাঠান")
            }
        }
    }
}
