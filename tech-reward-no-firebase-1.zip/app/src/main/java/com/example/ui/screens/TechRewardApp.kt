package com.example.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.repository.DemoAuthRepository
import com.example.data.repository.DemoRewardRepository
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.RegisterScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.reward.RewardScreen
import com.example.ui.screens.task.TasksScreen
import com.example.ui.screens.splash.SplashScreen

sealed class Screen(val route: String, val label: String, val icon: ImageVector?) {
    object Splash : Screen("splash", "Splash", null)
    object Login : Screen("login", "Login", null)
    object Register : Screen("register", "Register", null)
    object Home : Screen("home", "হোম", Icons.Filled.Home)
    object Tasks : Screen("tasks", "কাজ", Icons.Filled.List)
    object Reward : Screen("reward", "Reward", Icons.Filled.Star)
    object Profile : Screen("profile", "প্রোফাইল", Icons.Filled.Person)
    object WatchAd : Screen("watch_ad", "Watch Ad", null)
    object DailyBonus : Screen("daily_bonus", "Daily Bonus", null)
    object SpinWin : Screen("spin_win", "Spin & Win", null)
    object WithdrawalHistory : Screen("withdrawal_history", "Withdrawal History", null)
    object CoinHistory : Screen("coin_history", "Coin History", null)
    object AdminDashboard : Screen("admin_dashboard", "Admin Dashboard", null)
}

val bottomNavItems = listOf(Screen.Home, Screen.Tasks, Screen.Reward, Screen.Profile)

@Composable
fun TechRewardApp(
    authRepo: DemoAuthRepository,
    rewardRepo: DemoRewardRepository
) {
    val navController = rememberNavController()
    
    Scaffold(
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination
            val isBottomNavVisible = bottomNavItems.any { it.route == currentDestination?.route }
            
            if (isBottomNavVisible) {
                NavigationBar {
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            icon = { screen.icon?.let { Icon(it, contentDescription = screen.label) } },
                            label = { Text(screen.label) },
                            selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                            onClick = {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Splash.route) {
                SplashScreen(onNavigate = { route -> 
                    navController.navigate(route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                })
            }
            composable(Screen.Login.route) {
                LoginScreen(authRepo, onLoginSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }, onNavigateToRegister = {
                    navController.navigate(Screen.Register.route)
                })
            }
            composable(Screen.Register.route) {
                RegisterScreen(authRepo, onRegisterSuccess = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }, onNavigateToLogin = {
                    navController.popBackStack()
                })
            }
            composable(Screen.Home.route) {
                HomeScreen(authRepo, rewardRepo, onNavigate = { route -> navController.navigate(route) })
            }
            composable(Screen.Tasks.route) {
                TasksScreen(authRepo, rewardRepo, onNavigate = { route -> navController.navigate(route) })
            }
            composable(Screen.Reward.route) {
                RewardScreen(authRepo, rewardRepo)
            }
            composable(Screen.Profile.route) {
                ProfileScreen(authRepo, rewardRepo, onLogout = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }, onNavigate = { route -> navController.navigate(route) })
            }
            composable(Screen.WatchAd.route) {
                com.example.ui.screens.task.WatchAdScreen(authRepo, rewardRepo, onBack = { navController.popBackStack() })
            }
            composable(Screen.DailyBonus.route) {
                com.example.ui.screens.task.DailyBonusScreen(authRepo, rewardRepo, onBack = { navController.popBackStack() })
            }
            composable(Screen.SpinWin.route) {
                com.example.ui.screens.task.SpinWinScreen(authRepo, rewardRepo, onBack = { navController.popBackStack() })
            }
            composable(Screen.WithdrawalHistory.route) {
                com.example.ui.screens.profile.WithdrawalHistoryScreen(authRepo, rewardRepo, onBack = { navController.popBackStack() })
            }
            composable(Screen.CoinHistory.route) {
                com.example.ui.screens.profile.CoinHistoryScreen(authRepo, rewardRepo, onBack = { navController.popBackStack() })
            }
            composable(Screen.AdminDashboard.route) {
                com.example.ui.screens.admin.AdminDashboardScreen(rewardRepo, onBack = { navController.popBackStack() })
            }
        }
    }
}
