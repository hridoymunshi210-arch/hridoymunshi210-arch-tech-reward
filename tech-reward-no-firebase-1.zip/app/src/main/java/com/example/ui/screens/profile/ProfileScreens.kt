package com.example.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Transaction
import com.example.data.model.Withdrawal
import com.example.data.repository.AuthRepository
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileScreen(authRepo: AuthRepository, rewardRepo: RewardRepository, onLogout: () -> Unit, onNavigate: (String) -> Unit) {
    val currentUser by authRepo.currentUser.collectAsState(initial = null)
    val scope = rememberCoroutineScope()

    if (currentUser == null) return

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "প্রোফাইল",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            IconButton(onClick = { /* TODO: Settings */ }) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings")
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = currentUser?.name ?: "", style = MaterialTheme.typography.titleLarge)
                Text(text = currentUser?.email ?: "", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Total Coin", style = MaterialTheme.typography.labelSmall)
                        Text("${currentUser?.coinBalance}", fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("Earned", style = MaterialTheme.typography.labelSmall)
                        Text("${currentUser?.totalEarned}", fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("Withdrawn", style = MaterialTheme.typography.labelSmall)
                        Text("${currentUser?.totalWithdrawn}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        OutlinedButton(onClick = { /* TODO */ }, modifier = Modifier.fillMaxWidth()) {
            Text("প্রোফাইল সম্পাদনা")
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(onClick = { onNavigate("coin_history") }, modifier = Modifier.fillMaxWidth()) {
            Text("Coin History")
        }
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(onClick = { onNavigate("withdrawal_history") }, modifier = Modifier.fillMaxWidth()) {
            Text("Withdrawal History")
        }
        
        if (currentUser?.isAdmin == true) {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = { onNavigate("admin_dashboard") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("Admin Dashboard")
            }
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = {
                scope.launch {
                    authRepo.logout()
                    onLogout()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
            Text("Logout")
        }
        
        if (authRepo.isDemoMode) {
            Spacer(modifier = Modifier.weight(1f))
            Text("DEMO MODE", color = MaterialTheme.colorScheme.error, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WithdrawalHistoryScreen(authRepo: AuthRepository, rewardRepo: RewardRepository, onBack: () -> Unit) {
    var history by remember { mutableStateOf<List<Withdrawal>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        history = rewardRepo.getWithdrawalHistory()
        isLoading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Withdrawal History") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (history.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("এখনও কোনো withdrawal request নেই।")
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                items(history) { item ->
                    Card(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(item.method, fontWeight = FontWeight.Bold)
                                Text(formatDate(item.createdAt), style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("-${item.coinAmount} Coin", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                Text(item.status, color = if (item.status == "Pending") MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoinHistoryScreen(authRepo: AuthRepository, rewardRepo: RewardRepository, onBack: () -> Unit) {
    var history by remember { mutableStateOf<List<Transaction>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        history = rewardRepo.getTransactionHistory()
        isLoading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Coin History") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (history.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("এখনও কোনো Coin History নেই।")
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                items(history) { item ->
                    Card(modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(item.type, fontWeight = FontWeight.Bold)
                                Text(formatDate(item.createdAt), style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                val amountStr = if (item.amount > 0) "+${item.amount}" else "${item.amount}"
                                val color = if (item.amount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                Text("$amountStr Coin", color = color, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
