package com.example.ui.screens.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.repository.AuthRepository
import com.example.data.repository.RewardRepository

@Composable
fun HomeScreen(authRepo: AuthRepository, rewardRepo: RewardRepository, onNavigate: (String) -> Unit) {
    val currentUser by authRepo.currentUser.collectAsState(initial = null)
    
    if (currentUser == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "হ্যালো, ${currentUser?.name} 👋",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
        
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "আপনার Coin", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${currentUser?.coinBalance ?: 0}",
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
        
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(
                    onClick = { onNavigate("watch_ad") },
                    modifier = Modifier.weight(1f).padding(end = 4.dp)
                ) {
                    Text("📺 বিজ্ঞাপন")
                }
                Button(
                    onClick = { onNavigate("daily_bonus") },
                    modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                ) {
                    Text("🎁 Bonus")
                }
                Button(
                    onClick = { onNavigate("spin_win") },
                    modifier = Modifier.weight(1f).padding(start = 4.dp)
                ) {
                    Text("🎡 Spin")
                }
            }
        }
        
        item {
            Text(text = "আজকের কাজ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        
        item {
            TaskPreviewCard(title = "বিজ্ঞাপন দেখুন", icon = Icons.Filled.PlayArrow, onClick = { onNavigate("watch_ad") })
        }
        item {
            TaskPreviewCard(title = "Daily Bonus", icon = Icons.Filled.Star, onClick = { onNavigate("daily_bonus") })
        }
        item {
            TaskPreviewCard(title = "Available Tasks", icon = Icons.Filled.List, onClick = { onNavigate("tasks") })
        }
    }
}

@Composable
fun TaskPreviewCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
