package com.example.ui.screens.task

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Task
import com.example.data.repository.AuthRepository
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.launch

@Composable
fun TasksScreen(authRepo: AuthRepository, rewardRepo: RewardRepository, onNavigate: (String) -> Unit) {
    var tasks by remember { mutableStateOf<List<Task>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        tasks = rewardRepo.getTasks()
        isLoading = false
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "কাজ করুন",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        message?.let {
            Text(text = it, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(8.dp))
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(tasks) { task ->
                    TaskCard(task, onStart = {
                        if (task.type == com.example.data.model.TaskType.REWARDED_AD) {
                            onNavigate("watch_ad")
                        } else {
                            // Demo task completion
                            scope.launch {
                                val res = rewardRepo.completeTask(task.id)
                                if (res.isSuccess) {
                                    message = "অভিনন্দন! আপনি ${task.rewardCoins} Coin পেয়েছেন।"
                                } else {
                                    message = "দুঃখিত, কাজটি সম্পন্ন করা যায়নি।"
                                }
                            }
                        }
                    })
                }
            }
        }
    }
}

@Composable
fun TaskCard(task: Task, onStart: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = task.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(text = "Reward: +${task.rewardCoins} Coin", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
            }
            Button(onClick = onStart) {
                Text("শুরু করুন")
            }
        }
    }
}
