package com.example.ui.screens.task

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.repository.AuthRepository
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpinWinScreen(authRepo: AuthRepository, rewardRepo: RewardRepository, onBack: () -> Unit) {
    var isSpinning by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Spin & Win 🎡") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            
            // Simple wheel placeholder
            Card(
                modifier = Modifier.size(200.dp),
                shape = androidx.compose.foundation.shape.CircleShape,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("10, 20, 30, 50, 100", style = MaterialTheme.typography.titleMedium)
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            message?.let {
                Text(text = it, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary)
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            Button(
                onClick = {
                    isSpinning = true
                    message = null
                    scope.launch {
                        val res = rewardRepo.spinWheel()
                        if (res.isSuccess) {
                            message = "🎉 আপনি ${res.getOrNull()} Coin পেয়েছেন!"
                        } else {
                            message = res.exceptionOrNull()?.message ?: "দুঃখিত, স্পিন করা যায়নি।"
                        }
                        isSpinning = false
                    }
                },
                enabled = !isSpinning,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                if (isSpinning) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("SPIN করুন", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}
