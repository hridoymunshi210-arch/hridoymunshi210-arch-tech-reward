package com.example.ui.screens.task

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.repository.AuthRepository
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WatchAdScreen(authRepo: AuthRepository, rewardRepo: RewardRepository, onBack: () -> Unit) {
    var isAdLoading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("বিজ্ঞাপন দেখে Coin অর্জন করুন") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "একটি সম্পূর্ণ Rewarded Ad দেখুন",
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "+10 Coin",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(32.dp))
            
            message?.let {
                Text(text = it, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.secondary)
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            Button(
                onClick = {
                    isAdLoading = true
                    message = null
                    scope.launch {
                        delay(2000) // Simulate ad loading and watching
                        val tasks = rewardRepo.getTasks()
                        val adTask = tasks.find { it.type == com.example.data.model.TaskType.REWARDED_AD }
                        if (adTask != null) {
                            val res = rewardRepo.completeTask(adTask.id)
                            if (res.isSuccess) {
                                message = "অভিনন্দন! আপনি ১০ Coin পেয়েছেন।"
                            } else {
                                message = "এই মুহূর্তে বিজ্ঞাপন পাওয়া যাচ্ছে না। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
                            }
                        }
                        isAdLoading = false
                    }
                },
                enabled = !isAdLoading,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                if (isAdLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text("📺 বিজ্ঞাপন দেখুন", style = MaterialTheme.typography.titleMedium)
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "TEST MODE ACTIVE", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
}
