package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryGreen = Color(0xFF00C853)
val PrimaryGreenDark = Color(0xFF009624)
val SecondaryGreen = Color(0xFFB9F6CA)
val BackgroundLight = Color(0xFFF5F5F5)
val SurfaceLight = Color(0xFFFFFFFF)
val TextDark = Color(0xFF212121)
val TextGray = Color(0xFF757575)
val ErrorRed = Color(0xFFD32F2F)
